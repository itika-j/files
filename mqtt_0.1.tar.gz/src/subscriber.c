#include <stdio.h>
#include <pthread.h>
#include <mosquitto.h>
#include <string.h>
#include "../include/subscriber.h"

void on_connect(struct mosquitto *mosq, void *userdata, int rc) {
    if (rc == 0) {
        printf("Connected to MQTT broker\n");
    } else {
        fprintf(stderr, "Failed to connect: %s\n", mosquitto_connack_string(rc));
    }
}

void on_message(struct mosquitto *mosq, void *userdata, const struct mosquitto_message *msg) {
    printf("Received message on topic %s: %s\n", msg->topic, (char *)msg->payload);
}

void *subscriber_thread(void *arg) {
    struct SubscriberThreadData *data = (struct SubscriberThreadData *)arg;

    mosquitto_lib_init();

    char unique_id[20];
    snprintf(unique_id, sizeof(unique_id), "subscribe-%lu", (unsigned long)pthread_self());

    data->mosq = mosquitto_new(unique_id, true, NULL);

    if (!data->mosq) {
        fprintf(stderr, "Error: Out of memory.\n");
        return NULL;
    }

    mosquitto_connect_callback_set(data->mosq, on_connect);
    mosquitto_message_callback_set(data->mosq, on_message);

    if (mosquitto_connect(data->mosq, data->broker_ip, BROKER_PORT, 10) != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Unable to connect to the broker.\n");
        return NULL;
    }

    mosquitto_subscribe(data->mosq, NULL, data->topic, 0);

    int rc;
    do {
        rc = mosquitto_loop(data->mosq, -1, 1);
    } while (rc == MOSQ_ERR_SUCCESS);

    mosquitto_destroy(data->mosq);
    mosquitto_lib_cleanup();

    return NULL;
}
