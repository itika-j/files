#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <mosquitto.h>
#include "../include/subscriber.h"
#include "../include/publisher.h"

#define MAX_MESSAGE_LENGTH 100
#define MAX_SUB_THREADS 10

int main() {
    char broker_ip[20];
    char input[MAX_MESSAGE_LENGTH];

    struct mosquitto *pub_mosq = NULL;

    pthread_t sub_threads[MAX_SUB_THREADS];
    struct SubscriberThreadData sub_thread_data[MAX_SUB_THREADS];
    int num_sub_threads = 0;

    while (1) {
        printf("Enter command (connect/subscribe/publish/quit): ");
        fgets(input, sizeof(input), stdin);
        strtok(input, "\n");

        if (strcmp(input, "connect") == 0) {
            printf("Enter MQTT broker IP address: ");
            fgets(broker_ip, sizeof(broker_ip), stdin);
            strtok(broker_ip, "\n");

            initialize_mosquitto(&pub_mosq, broker_ip);
        } else if (strcmp(input, "subscribe") == 0) {
            if (num_sub_threads < MAX_SUB_THREADS) {
                char subscriber_topic[50];
                printf("Enter subscriber topic: ");
                fgets(subscriber_topic, sizeof(subscriber_topic), stdin);
                strtok(subscriber_topic, "\n");

                sub_thread_data[num_sub_threads].topic = strdup(subscriber_topic);
                sub_thread_data[num_sub_threads].broker_ip = broker_ip;

                if (pthread_create(&sub_threads[num_sub_threads], NULL, subscriber_thread, &sub_thread_data[num_sub_threads]) != 0) {
                    fprintf(stderr, "Error creating subscriber thread.\n");
                    return 1;
                }
                num_sub_threads++;
            } else {
                fprintf(stderr, "Maximum number of subscriber threads reached.\n");
            }
        } else if (strcmp(input, "publish") == 0) {
            if (pub_mosq == NULL) {
                printf("Please connect to MQTT broker first.\n");
            } else {
                char publisher_topic[50];
                printf("Enter a message to publish (or 'quit' to exit): ");
                fgets(input, sizeof(input), stdin);
                strtok(input, "\n");

                if (strcmp(input, "quit") == 0) {
                    break;
                }

                printf("Enter publisher topic: ");
                fgets(publisher_topic, sizeof(publisher_topic), stdin);
                strtok(publisher_topic, "\n");

                publish_message(pub_mosq, input, publisher_topic);
            }
        } else if (strcmp(input, "quit") == 0) {
            break;
        } else {
            printf("Invalid command.\n");
        }
    }

    if (pub_mosq) {
        cleanup_mosquitto(pub_mosq);
    }

    for (int i = 0; i < num_sub_threads; i++) {
        pthread_cancel(sub_threads[i]);
        pthread_join(sub_threads[i], NULL);
        cleanup_mosquitto(sub_thread_data[i].mosq);
        free(sub_thread_data[i].topic);
    }

    return 0;
}
