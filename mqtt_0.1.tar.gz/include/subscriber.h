#ifndef SUBSCRIBER_H
#define SUBSCRIBER_H

#include <mosquitto.h>

#define BROKER_PORT 1883

struct SubscriberThreadData {
    struct mosquitto *mosq;
    const char *topic;
    const char *broker_ip;
};

void *subscriber_thread(void *arg);

#endif // SUBSCRIBER_H
